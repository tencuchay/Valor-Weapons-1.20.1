package com.valor.weapons.util;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.registries.ForgeRegistries;

/** Damage of Sun's Bow projectiles: 100% of minecraft:generic.attack_damage. */
public final class SunBowDamage {
    public static final ResourceLocation RANGED_ATTACK_ID = new ResourceLocation("valor_items", "ranged_attack");

    /** Projectile damage = this fraction of the attack damage stat. */
    public static final double SCALE = 1.0D;

    private SunBowDamage() {}

    /** The attribute instance of valor_items:ranged_attack on this entity, or null if the mod/attribute is missing. */
    public static AttributeInstance rangedAttack(LivingEntity entity) {
        if (!ForgeRegistries.ATTRIBUTES.containsKey(RANGED_ATTACK_ID)) {
            return null;
        }
        Attribute attribute = ForgeRegistries.ATTRIBUTES.getValue(RANGED_ATTACK_ID);
        return attribute == null ? null : entity.getAttribute(attribute);
    }

    public static float projectileDamage(LivingEntity attacker) {
        return (float) (attacker.getAttributeValue(Attributes.ATTACK_DAMAGE) * SCALE);
    }
}
